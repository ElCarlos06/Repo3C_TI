package mx.edu.utez.demo3.dao.impl;

public class AlumnoImplDao {
}
