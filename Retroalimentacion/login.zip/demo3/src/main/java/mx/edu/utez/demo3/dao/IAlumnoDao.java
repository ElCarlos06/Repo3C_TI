package mx.edu.utez.demo3.dao;

import mx.edu.utez.demo3.model.Alumno;

import java.util.List;

public interface IAlumnoDao {

    public List<Alumno> findAll() throws Exception;
    public Alumno getById(int id) throws Exception;
    void create(Alumno alumno) throws Exception;
    void update(Alumno alumno) throws Exception;
    void delete(Alumno alumno) throws Exception;

}
